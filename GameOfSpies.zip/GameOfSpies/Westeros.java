// Westeros.java

import static java.lang.System.out;

import greenfoot.*;
import java.util.LinkedList;
import java.util.List;

/**
 * Class representing Westeros, the world to be explored by the Spies, to spy on Ned Stark
 * 
 * @author Sebastien Combefis (UCLouvain)
 * @author Fabien Duchene (UCLouvain)
 * @version September 17, 2015
 */
public class Westeros extends World
{
    // Constants
    public static final GreenfootImage snow = new GreenfootImage ("snow.png");
    public static final GreenfootImage fir = new GreenfootImage ("fir.png");
    
    // Instance variables
    private final NedStark NedStark = new NedStark();
    
    /**
     * Create a new Westeros world, with specified width and height,
     * and with Ned Stark located at (x, y)
     */
    public Westeros (int width, int height, int x, int y)
    {
        super (width, height, 48);
        for (SequentialActor sa : previousactors)
        {
            sa.kill();
        }
        previousactors.clear();
        
        out.println ("\u000C"); // Clears the terminal
        setBackground (snow);
        super.addObject (NedStark, x, y);
    }

    /**
     * Create a new Westeros world, with 16 x 12 cells,
     * and with Ned Stark located at (15, 6)
     */
    public Westeros()
    {
        this (16, 12, 15, 6);
    }
    
    /**
     * Get the x-coordinate of Walter
     */
    public int getTargetX()
    {
        return NedStark.getX();
    }
    
    /**
     * Get the y-coordinate of Walter
     */
    public int getTargetY()
    {
        return NedStark.getY();
    }
    
    /**
     * Heal Walter
     */
    public void spyOnTarget()
    {
        NedStark.setImage (snow);
    }
    
    public void buildScenario1()
    {
        placeObjects (Fir.class, new int[] {9, 4, 9, 5, 9, 6, 10, 6, 11, 6, 12, 6, 12, 5, 9, 8, 8, 8, 7, 8, 6, 7, 6, 8, 6, 6, 5, 6, 3, 6, 4, 6, 2, 3, 4, 2, 5, 4, 7, 3, 6, 1, 9, 1, 14, 10, 13, 9, 10, 10, 2, 9, 5, 10});
        placeObjects (Wolf.class, new int[] {12, 4, 11, 2, 14, 1, 14, 4, 13, 7, 11, 9, 7, 10, 3, 9, 1, 7, 1, 4, 1, 1});
        super.addObject (new Spies(), 5, 7);
    }
    
    public void buildScenario2()
    {
        placeObjects (Fir.class, new int[] {4, 5, 3, 8, 7, 9, 8, 6, 10, 4, 12, 8, 14, 10, 7, 3, 3, 2, 1, 10, 11, 2, 14, 1, 13, 5, 2, 6});
        super.addObject (new Spies(), 0, 6);
    }
    
    public void buildScenario3()
    {        
        placeObjects (Fir.class, new int[] {6, 9, 7, 7, 9, 8, 1, 9, 3, 7, 5, 5, 11, 8, 4, 3, 1, 2, 1, 4, 8, 1, 13, 2, 13, 5, 14, 8, 14, 10, 13, 1, 13, 4, 13, 3});
        placeObjects (Wolf.class, new int[] {9, 5, 7, 4, 6, 2, 10, 1, 11, 6, 12, 2, 8, 5, 5, 7, 3, 1, 9, 10, 12, 10, 1, 6});
        super.addObject (new Spies(), 3, 9);
    }
    
    public void buildScenario4()
    {
        placeObjects (Fir.class, new int[] {6, 9, 5, 6, 2, 3, 7, 2, 9, 5, 13, 2, 11, 9, 14, 10});
        placeObjects (Wolf.class, new int[] {1, 7, 5, 4, 2, 1, 9, 3, 13, 6, 9, 8, 14, 4, 3, 6});
        super.addObject (new Spies(), 2, 9);
    }
    
    public void buildScenario5()
    {
        placeObjects (Fir.class, new int[] {14, 8, 13, 4, 8, 5, 8, 3, 12, 1, 5, 3, 1, 2, 1, 7, 5, 9, 8, 10, 12, 10});
        placeObjects (Wolf.class, new int[] {11, 5, 2, 10, 6, 7, 6, 1, 9, 1, 14, 2, 4, 6});
        super.addObject (new Spies(), 10, 8);
    }
    
    public void buildScenario6()
    {
        placeObjects (Fir.class, new int[] {10, 1, 11, 3, 4, 5, 12, 6, 12, 5, 11, 7, 10, 7, 12, 7, 2, 5, 3, 5, 2, 6, 2, 7, 2, 8, 4, 7, 4, 6, 3, 7, 2, 9, 5, 2, 2, 2, 8, 4, 4, 1, 14, 10, 14, 3, 14, 5, 1, 11, 12, 9});
        placeObjects (Wolf.class, new int[] {7, 5, 7, 6, 7, 7, 7, 8, 7, 9, 8, 9, 9, 9, 12, 10, 14, 7, 10, 4, 7, 2, 4, 9});
        super.addObject (new Spies(), 13, 1);
    }
    
    public void buildScenario7()
    {
        placeObjects (Fir.class, new int[] {7, 3, 10, 4, 9, 7, 7, 9, 4, 8, 5, 5, 4, 3, 2, 1, 1, 5, 2, 10, 12, 10, 14, 8, 13, 4, 14, 2, 10, 1, 6, 1});
        super.addObject (new Spies(), 5, 6);
    }
    
    public void buildScenario8()
    {
        placeObjects (Fir.class, new int[] {2, 9, 1, 7, 3, 5, 2, 3, 6, 1, 6, 5, 4, 2, 10, 3, 11, 1, 13, 4, 10, 6, 14, 8, 13, 10, 10, 10, 11, 8, 7, 9, 5, 8, 4, 10, 1, 1, 8, 4, 13, 2});
        super.addObject (new Spies(), 0, 9);
    }
    
    public void buildScenario9()
    {
        placeObjects (Fir.class, new int[] {2, 1, 2, 3, 3, 3, 3, 5, 1, 5, 3, 7, 3, 8, 3, 9, 1, 9, 1, 10, 5, 6, 5, 5, 5, 4, 5, 2, 7, 3, 8, 3, 9, 3, 8, 1, 7, 5, 7, 7, 7, 8, 7, 9, 7, 10, 9, 8, 10, 10, 11, 10, 9, 6, 10, 6, 11, 6, 12, 6, 13, 9, 13, 8, 11, 4, 11, 3, 11, 2, 11, 1, 13, 2, 14, 4});
        super.addObject (new Spies(), 3, 4);
    }
    
    public void buildScenario10()
    {
        placeObjects (Fir.class, new int[] {1, 2, 3, 1, 3, 3, 4, 3, 2, 5, 1, 10, 2, 10, 3, 10, 2, 8, 3, 8, 4, 8, 6, 7, 6, 6, 6, 5, 6, 4, 6, 3, 6, 2, 9, 3, 11, 2, 12, 2, 9, 5, 10, 5, 11, 5, 8, 7, 8, 8, 8, 9, 8, 10, 12, 7, 14, 8, 14, 9, 14, 10});
        placeObjects (Wolf.class, new int[] {4, 6, 9, 1, 6, 9, 10, 8, 10, 10, 12, 9, 13, 5, 14, 3});
        super.addObject (new Spies(), 4, 5);
    }
    
    public void buildScenario11()
    {
        placeObjects (Fir.class, new int[] {4, 3, 4, 4, 4, 5, 4, 6, 4, 7, 10, 6, 11, 6, 13, 6, 12, 6, 7, 4, 8, 4, 9, 4, 7, 9, 10, 10, 13, 10, 14, 3, 10, 2, 7, 2, 2, 1, 1, 9, 1, 10, 9, 10, 3, 9, 4, 9, 5, 9, 7, 7, 14, 1});
        placeObjects (Wolf.class, new int[] {14, 8, 9, 8, 11, 4, 12, 2, 5, 1, 2, 3, 1, 5, 2, 7});
        super.addObject (new Spies(), 11, 8);
    }
    
    public void buildScenario12()
    {
        placeObjects (Fir.class, new int[] {2, 0, 1, 3, 2, 3, 3, 3, 2, 4, 2, 6, 2, 7, 2, 8, 1, 10, 5, 7, 5, 8, 5, 11, 6, 6, 7, 6, 8, 6, 6, 5, 6, 4, 7, 3, 8, 4, 5, 2, 6, 1, 8, 0, 9, 7, 9, 8, 11, 8, 11, 7, 13, 8, 14, 10, 11, 11, 11, 5, 11, 4, 11, 3, 13, 1, 14, 2});
        super.addObject (new Spies(), 4, 5);
    }
    
    public void buildScenario13()
    {
        placeObjects (Fir.class, new int[] {2, 2, 4, 1, 6, 0, 6, 1, 6, 2, 6, 3, 8, 3, 8, 5, 8, 6, 8, 7, 8, 8, 8, 9, 8, 11, 7, 11, 6, 11, 5, 11, 0, 9, 1, 9, 2, 9, 1, 5, 2, 5, 4, 5, 3, 5, 11, 3, 11, 2, 14, 3, 14, 5, 14, 7, 15, 7, 13, 7, 12, 7, 11, 7, 10, 7, 10, 9, 10, 10, 10, 11, 15, 9});
        placeObjects (Wolf.class, new int[] {13, 11, 12, 9, 10, 5, 12, 5, 13, 1, 8, 1, 6, 6, 2, 7, 4, 8, 6, 9});
        super.addObject (new Spies(), 3, 4);
    }
    
    public void buildScenario14()
    {
        placeObjects (Fir.class, new int[] {3, 6, 4, 6, 4, 5, 6, 3, 7, 3, 7, 4, 6, 8, 7, 8, 8, 8, 9, 8, 2, 9, 2, 10, 3, 10, 11, 2, 10, 2, 11, 3, 13, 1, 13, 6, 13, 7, 13, 8, 10, 10, 11, 10, 11, 9, 1, 3, 1, 2, 2, 2, 6, 11, 6, 10, 13, 2, 14, 2});
        placeObjects (Wolf.class, new int[] {9, 6, 11, 7, 11, 5, 9, 4, 6, 6, 4, 8, 1, 7, 1, 5, 4, 3, 4, 1, 14, 4, 8, 10});
        super.addObject (new Spies(), 7, 1);
    }
    
    public void buildScenario15()
    {
        placeObjects (Fir.class, new int[] {4, 3, 1, 4, 1, 5, 3, 6, 1, 9, 4, 8, 4, 7, 9, 3, 8, 5, 8, 6, 8, 8, 13, 10, 10, 3, 10, 9, 9, 1, 5, 10, 2, 1, 8, 7, 11, 3, 2, 9, 6, 5, 2, 6, 3, 3, 2, 3, 13, 4, 6, 0, 7, 1, 8, 4, 11, 1, 10, 0, 5, 1, 11, 9, 11, 6, 9, 9, 3, 9, 13, 8, 14, 6, 14, 1, 1, 11});
super.addObject (new Spies(), 11, 8);
    }
    
    // Methods to create scenarii
    private void placeObjects (Class<? extends Actor> objectType, int[] coords)
    {
        for (int i = 0; i < coords.length - 1; i += 2)
        {
            try
            {
                super.addObject (objectType.newInstance(), coords[i], coords[i + 1]);
            }
            catch (Exception exception){}
        }
    }
    
    public void printObjects()
    {
        StringBuilder buff = new StringBuilder();
        for (Object a : getObjects (Fir.class))
        {
            Fir r = (Fir) a;
            buff.append (r.getX()).append (", ").append (r.getY()).append (", ");
        }
        buff.delete (buff.length() - 2, buff.length());
        out.println ("placeObjects (Building.class, new int[] {" + buff + "});");
        
        buff = new StringBuilder();
        for (Object a : getObjects (Wolf.class))
        {
            Wolf r = (Wolf) a;
            buff.append (r.getX()).append (", ").append (r.getY()).append (", ");
        }
        if (buff.length() > 0)
        {
            buff.delete (buff.length() - 2, buff.length());
            out.println ("placeObjects (Zombie.class, new int[] {" + buff + "});");
        }
        
        buff = new StringBuilder();
        for (Object a : getObjects (Spies.class))
        {
            Spies r = (Spies) a;
            buff.append (r.getX()).append (", ").append (r.getY()).append (", ");
        }
        buff.delete (buff.length() - 2, buff.length());
        out.println ("super.addObject (new Ikuse(), " + buff + ");");
    }
    
    // Old actors to be killed at each reset
    private static List<SequentialActor> previousactors = new LinkedList<SequentialActor>();
    
    @Override
    public synchronized void addObject (Actor actor, int x, int y)
    {
        if (! (actor instanceof NedStark || actor.getClass() == Human.class))
        {
            super.addObject (actor, x, y);
            if (actor instanceof SequentialActor)
            {
                previousactors.add ((SequentialActor) actor);
            }
        }
    }
    
    @Override
    public synchronized void removeObject (Actor actor)
    {
        if (actor != NedStark)
        {
            super.removeObject (actor);
        }
    }
}