// SequentialActor.java

import greenfoot.*;

/**
 * An actor variant which allows sequential-style programming.
 * <p>
 * To use this class, extend it and override the "behave()" method, which can be
 * written in sequential style. From within the behave() method call
 * "waitForTurn()" in between each separate action.
 * 
 * @author David McCall (adepted by Sebastien Combefis (UCLouvain) on September 15, 2011)
 * @version 1.1
 */
public class SequentialActor extends Actor
{
    // Instance variables
    private final Thread saThread;
    private boolean isMyTurn;
    private boolean finished;
    
    /**
     * Constructor
     */
    protected SequentialActor()
    {
        (saThread = new Thread() {
            public void run()
            {
                waitForTurn();
                behave();
                
                synchronized (SequentialActor.this)
                {
                    finished = true;
                    SequentialActor.this.notify();
                }
            }
        }).start();
    }
    
    /**
     * Call this method to wait for the next "turn". In other words, wait until
	 * all other actors have had a chance to move.
     */
    protected synchronized void waitForTurn()
    {
        // This method gets called when one turn is over; set isMyTurn false to
        // mark that the turn is over.
        isMyTurn = false;
        notify();
        
        // Now wait for the next turn, which will be signalled from the act() method.
        while (! isMyTurn)
        {
            try
            {
                wait();
            }
            catch (InterruptedException exception){}
        }
    }
    
    /**
     * Act - do whatever the SequentialActor wants to do. This method is called
	 * whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    @Override
    public final synchronized void act()
    {
        if (! finished)
        {
            isMyTurn = true;
            notify();
            
            // Wait until the turn has completed
            while (isMyTurn && ! finished)
            {
                try
                {
                    wait();
                }
                catch (InterruptedException exception){}
            }
        }
    }
    
    /**
     * Behave - override this method to implement the desired behaviour
     */
    protected void behave(){}
    
    
    
    
    // New methods
	private boolean alive = true;
	
	@SuppressWarnings ("deprecation")
	final synchronized void kill()
	{
		alive = false;
		isMyTurn = false;
		finished = true;
		notify();
		saThread.stop();
	}

	final boolean isAlive()
	{
		return alive;
	}
}