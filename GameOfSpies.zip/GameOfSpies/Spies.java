// Spies.java

import greenfoot.*;

/**
 * Class representing Philip and Elizatbeh, the spies
 * 
 * @author Sebastien Combefis (UCLouvain)
 * @author Fabien Duchene (UCLouvain)
 * @version September 18, 2015
 */
public class Spies extends Human
{
    protected void behave()
    {
       
    }
}