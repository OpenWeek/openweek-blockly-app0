// Wolf.java

import greenfoot.*;

/**
 * Class representing a Wolf. 
 * 
 * @author Sebastien Combefis (UCLouvain)
 * @author Fabien Duchene (UCLouvain)
 * @version September 18, 2015
 */
public class Wolf extends Actor
{
    public Wolf(){}
}