// NedStark.java

import greenfoot.*;

/**
 * Class representing NedStark, the target
 * 
 * @author Sebastien Combefis (UCLouvain)
 * @author Fabien Duchene (UCLouvain)
 * @version September 18, 2015
 */
public class NedStark extends Actor
{
    public NedStark(){}
}