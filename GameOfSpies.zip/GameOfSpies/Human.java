// Human.java

import static java.lang.System.out;

import greenfoot.*;
import java.util.List;
import java.awt.Color;

/**
 * A Human which can move in a squared grid, oriented along the cardinal
 * points (NORTH, SOUTH, EAST, WEST). At each step, the Spies can turn on
 * itself, move of one cell in the current direction, dig in the ground or
 * pick up the gem. He knows his coordinates and those of Ned Stark.
 * 
 * @author Sebastien Combefis (UCLouvain)
 * @author Fabien Duchene (UCLouvain)
 * @version September 18, 2015
 */
public class Human extends SequentialActor
{
    // Enumeration to represents the direction
    public enum Direction { NORTH, EAST, SOUTH, WEST };
    
    // Constants
    private static final int LIVE = 99;
    public static final GreenfootImage transparent = new GreenfootImage ("transparent-48.png");
    
    // Instance variables
    private Direction direction;
    private boolean foundNed;
    private int counter;
    private int steps;
    
    private final GreenfootImage HumanHoriz, HumanVert, HumanDead, HumanDamaged, NedStark;
    
    /**
     * Constructor
     */
    public Human()
    {
        HumanHoriz = getImage();
        
        HumanVert = new GreenfootImage (getImage());
        HumanVert.rotate (180);
        HumanVert.mirrorVertically();
        
        HumanDead = new GreenfootImage ("spies-dead.png");
        HumanDamaged = new GreenfootImage ("spies-sleeping.png");
        
        NedStark = new GreenfootImage ("nedstark.png");
        NedStark.scale (24, 24);
        
        setDirection (Direction.EAST);
        foundNed = false;
        counter = 0;
    }
    
    /**
     * Wait the next cycle
     */
    @Override
    protected synchronized final void waitForTurn()
    {
        super.waitForTurn();
        counter++;
    }
    
    /**
     * Human behaviour. Should be filled in extending classes
     */
    @Override
    protected void behave(){}
    
    /**
     * Move of one cell in the current direction.
     * - If there is a Fir, don't move
     * - If there is a Wolf, die
     * Duration: one cycle
     */
    public final void move()
    {
        if (canMove() && isAlive())
        {
            if (steps == LIVE)
            {
                Greenfoot.playSound ("sleeping.wav");
                out.println ("[" + this.getClass().getName() + "] Trop tard, l'hiver est arrivé...");
                setDirection (Direction.EAST);
                setImage (HumanDamaged);
                kill();
                
                waitForTurn();
                return;
            }
            
            setLocation (nextX (getX(), direction), nextY (getY(), direction));
            steps++;
            
            GreenfootImage Human = getImage();
            Human.setColor (Color.BLACK);
            Human.fillRect (-10, 35, 30, 10);
            Human.setColor (Color.WHITE);
            int nbDigits = (int) Math.log10 (steps) + 1;
            Human.setFont (Human.getFont().deriveFont (10f - (nbDigits - 1)));
            Human.drawString (String.valueOf (steps), 0, 42 + nbDigits);
            
            List<?> Wolves = getWorld().getObjectsAt (getX(), getY(), Wolf.class);
            if (! Wolves.isEmpty())
            {
                Greenfoot.playSound ("sword.wav");
                out.println ("[" + this.getClass().getName() + "] AAAAAaaaaaaahhhh un loup! *miam*. Vos agents viennent de se faire manger.");
                setDirection (Direction.EAST);
                
                for (Object o : Wolves)
                {
                    ((Actor) o).setImage (transparent);
                }
                setImage (HumanDead);
                kill();
            }
        }
        waitForTurn();
    }
    
    /**
     * Test whether there is a Wolf in front of the Human, in the current direction
     */
    public final boolean isInFrontOfWolf()
    {
        int x = nextX (getX(), direction);
        int y = nextY (getY(), direction);
        
        return ! getWorld().getObjectsAt (x, y, Wolf.class).isEmpty();
    }
    
    /**
     * Test is the Human can move, that is if there is no Fir in front
     * of him in the current direction, or if the Human is not against
     * the border of the world
     */
    public final boolean canMove()
    {
        if (! isAlive())
        {
            return false;
        }
        
        World myWorld = getWorld();
        int x = nextX (getX(), direction);
        int y = nextY (getY(), direction);

        if (x >= myWorld.getWidth() || y >= myWorld.getHeight() || x < 0 || y < 0)
        {
            return false;
        }

        return myWorld.getObjectsAt (x, y, Fir.class).isEmpty();
    }
    
    /**
     * Turn towards the left
     * Duration: one cycle
     */
    public final void turnLeft()
    {
        if (! isAlive())
        {
            return;
        }
        
        setDirection (left (direction));
        waitForTurn();
    }
    
    /**
     * Turn towards the right
     * Duration: one cycle
     */
    public final void turnRight()
    {
        if (! isAlive())
        {
            return;
        }
        
        setDirection (right (direction));
        waitForTurn();
    }
    
    /**
     * Set the direction of the Human
     */
    private void setDirection (Direction direction)
    {
        this.direction = direction;
        switch (direction)
        {
            case SOUTH:
                setImage (HumanVert);
                setRotation (90);
            break;
            case EAST:
                setImage (HumanHoriz);
                setRotation (0);
            break;
            case NORTH:
                setImage (HumanVert);
                setRotation (90);
            break;
            case WEST:
                setImage (HumanHoriz);
                setRotation (0);
            break;
        }
    }
    
    /**
     * Get the current direction
     */
    public final Direction getDirection()
    {
        return direction;
    }
    
    /**
     * Get the x-coordinate of Ned Stark
     */
    public final int getTargetX()
    {
        return ((Westeros) getWorld()).getTargetX();
    }
    
    /**
     * Get the y-coordinate of Ned Stark
     */
    public final int getTargetY()
    {
        return ((Westeros) getWorld()).getTargetY();
    }
    
    /**
     * Test if the Human is on Ned Stark
     */
    public final boolean isOnTarget()
    {
        return (getX() == getTargetX() && getY() == getTargetY());
    }
    
    /**
     * Spy on target. Prints information about the situation
     * Duration: one cycle
     */
    public final void spyOnTarget()
    {
        boolean found = false;
        if (! foundNed && isOnTarget())
        {
            Greenfoot.playSound ("tadaa.wav");
            printStats();
            found = true;
            foundNed = true;
            ((Westeros) getWorld()).spyOnTarget();
            mark();
        }

        System.out.println ("[" + this.getClass().getName() + "] " + (found ? "Cible localisée, espionnage en cours..." : "Le centre souhaiterait savoir pourquoi vous espionnez de la neige..."));
        waitForTurn();
    }
    
    /**
     * Change the image of the Human
     */
    private void mark()
    {
        HumanHoriz.drawImage (NedStark, 20, 20);
        HumanVert.drawImage (NedStark, 20, 20);
    }
    
    /**
     * Get the number of cycles since the beginning
     */
    private int getCounter()
    {
        return counter;
    }
    
    /**
     * Print stats about the Human
     */
    public void printStats()
    {
        out.println ("[" + this.getClass().getName() + "] Nombre de pas : " + steps + ", Temps ecoule : " + getCounter());
    }
    
    /*
     * Auxiliary methods to do computation on direction
     */

    // get the direction on the right of the specified one
    private Direction right (Direction dir)
    {
        switch (dir)
        {
            case EAST: return Direction.SOUTH;
            case WEST: return Direction.NORTH;
            case NORTH: return Direction.EAST;
            case SOUTH: return Direction.WEST;
        }
        
        assert false;
        return null;
    }

    // get the direction on the left of the specified one
    private Direction left (Direction dir)
    {
        switch (dir)
        {
            case EAST: return Direction.NORTH;
            case WEST: return Direction.SOUTH;
            case NORTH: return Direction.WEST;
            case SOUTH: return Direction.EAST;
        }
        
        assert false;
        return null;
    }

    // get x shifted of one cell long specified direction
    private int nextX (int x, Direction dir)
    {
        switch (dir)
        {
            case EAST: return x + 1;
            case WEST: return x - 1;
            case NORTH:
            case SOUTH: return x;
        }
        
        assert false;
        return -1;
    }

    // get y shifted of one cell along specified direction
    private int nextY (int y, Direction dir)
    {
        switch (dir)
        {
            case SOUTH: return y + 1;
            case NORTH: return y - 1;
            case EAST:
            case WEST: return y;
        }
        
        assert false;
        return -1;
    }
}